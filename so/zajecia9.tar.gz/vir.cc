#include <string>
#include <iostream>

class Osoba{
protected:
    std::string imie{"Jan"};
    std::string nazwisko{"Kowalski"};
    int wiek{25};
    
public:
    Osoba() = default;
    Osoba(const Osoba&) = default;
    Osoba(std::string imie_, std::string nazwisko_, int wiek_) :
    imie{imie_}, nazwisko{nazwisko_}, wiek{wiek_} {}
    
    virtual ~Osoba()
    {
        std::cout<<"Osoba destruktor: "<<nazwisko<<std::endl;
    }
 
    virtual void print(std::ostream& ost) const
    {
        ost<<imie<<", "<<nazwisko<<", "<<wiek;
    }
    
    virtual void read(std::istream& ist)
    {
        ist>>imie>>nazwisko>>wiek;
    }
    
    friend std::ostream& operator<<(std::ostream& ost, const Osoba& os)
    {
        os.print(ost);
        return ost;
    }
    
    friend std::istream& operator>>(std::istream& ist, Osoba& os)
    {
        os.read(ist);
        return ist;
    }
    
    virtual double zarobki() const = 0;
    
};

class Pracownik : public Osoba{
protected:
    double pensja{1000};
public:
    Pracownik() = default;
    Pracownik(const Pracownik&) = default;
    Pracownik(std::string imie_, std::string nazwisko_, int wiek_, double pensja_) :
    Osoba{imie_, nazwisko_, wiek_}, pensja{pensja_} {}
    
    virtual ~Pracownik()
    {
        std::cout<<"Pracownik destruktor: "<<nazwisko<<std::endl;
    }
    
    virtual void print(std::ostream& ost) const override
    {
        Osoba::print(ost);
        ost<<", "<<pensja;
    }
    
    virtual void read(std::istream& ist) override
    {
        Osoba::read(ist);
        ist>>pensja;
    }
    
    virtual double zarobki() const override
    {
        return pensja;
    }
    
};


class Pracownikplus : public Pracownik{
protected:
    double premia{0.25};
public:
    Pracownikplus() = default;
    Pracownikplus(const Pracownikplus&) = default;
    Pracownikplus(std::string imie_, std::string nazwisko_, int wiek_,
                  double pensja_, double premia_) :
                  Pracownik{imie_, nazwisko_, wiek_, pensja_},
                  premia{premia_} {}
    
    virtual ~Pracownikplus()
    {
        std::cout<<"Pracownikplus destruktor: "<<nazwisko<<std::endl;
    }
    
    virtual void print(std::ostream& ost) const override
    {
        Pracownik::print(ost);
        ost<<", "<<premia;
    }
    
    virtual void read(std::istream& ist) override
    {
        Pracownik::read(ist);
        ist>>premia;
    }    
    
    virtual double zarobki() const override
    {
        return (1+premia)*pensja;
    }
};

#include <vector>

/*
int main()
{
    Pracownik pracownik{"Andrzej", "Nowak", 30, 2500};
    Pracownikplus pracownikplus{"Edward", "Malec", 45, 5000, 0.3};
    
    std::vector<Osoba*> v{};
    
    v.push_back(&pracownik);
    v.push_back(&pracownikplus);

    for(const auto p : v)
        std::cout<<*p<<", "<<p->zarobki()<<std::endl;
    
    return 0;
}
*/

#include <fstream>

/*
int main()
{
    std::vector<Osoba*> vv{};
    
    Pracownik pp{};
    
    std::ifstream ist{"p.dat"};
    
    while(ist>>pp)
        vv.push_back(new Pracownik{pp});
    
    ist.close();
    
    Pracownikplus ppp{};
    
    std::ifstream istp{"pp.dat"};
    
    while(istp>>ppp)
        vv.push_back(new Pracownikplus{ppp});
    
    istp.close();
    
    for(const auto& p : vv)
        std::cout<<*p<<std::endl;
    
    for(auto& p : vv)
        delete p;
    
    return 0;
}
*/

#include <memory>

/*
int main()
{
    std::vector<std::unique_ptr<Osoba>> vv{};
    
    Pracownik pp{};
    
    std::ifstream ist{"p.dat"};
    
    while(ist>>pp)
        vv.push_back(std::make_unique<Pracownik>(pp));
    
    ist.close();
    
    Pracownikplus ppp{};
    
    std::ifstream istp{"pp.dat"};
    
    while(istp>>ppp)
        vv.push_back(std::make_unique<Pracownikplus>(ppp));
    
    istp.close();
    
    for(const auto& p : vv)
        std::cout<<*p<<std::endl;
    
    return 0;
}
*/

int main()
{
    std::vector<std::shared_ptr<Osoba>> vv{};
    
    Pracownik pp{};
    
    std::ifstream ist{"p.dat"};
    
    while(ist>>pp)
        vv.push_back(std::make_shared<Pracownik>(pp));
    
    ist.close();
    
    Pracownikplus ppp{};
    
    std::ifstream istp{"pp.dat"};
    
    while(istp>>ppp)
        vv.push_back(std::make_shared<Pracownikplus>(ppp));
    
    istp.close();
    
    for(const auto& p : vv)
        std::cout<<*p<<" zarobki: "<<p->zarobki()<<std::endl;
    
    
    return 0;
}

