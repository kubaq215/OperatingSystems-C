#include <iostream>

template <typename T>
class queue{
private:
    //definiujemy węzeł
    class qnode{
    public:
        T element{};
        qnode* next{};
        
        qnode(T e = T{}) : element{e}, next{nullptr} {}
    };
    
    qnode *first, *last;
    
public:
    // konstruktor
    queue() : first{nullptr}, last{nullptr} {}
    
    bool isempty() const
    {
        return first == nullptr;
    }
    
    // dodaj element do kolejki
    void enqueue(const T&);
    
    // obsłuż pierwszy element kolejki i usuń go
    T dequeue();
    
    void makeempty();
    void display(std::ostream&);
        
};

template <typename T>
void queue<T>::enqueue(const T& x)
{
    if(isempty())
    {
        first = new qnode{x};
        last = first;
    }
    else
    {
        qnode *p = new qnode{x};
        last->next = p;
        last = last->next;
                
    }
}

template <typename T>
T queue<T>::dequeue()
{
    T x{};
    qnode *p;
    
    if(not isempty())
    {
        x = first->element;
        p = first;
        first = first->next;
        
        delete p;
    }
    
    return x;
}


template <typename T>
void queue<T>::makeempty()
{
    while(not isempty())
        dequeue();
}


template <typename T>
void queue<T>::display(std::ostream& ost)
{
    if(isempty())
        ost<<"Kolejka jest pusta !"<<std::endl;
    
    for(qnode *p=first; p!=nullptr; p = p->next)
        ost<<p->element<<std::endl;
    
}


#include <string>

int main()
{
    
    queue<std::string> kol{};
    
    kol.enqueue("Janusz");
    kol.enqueue("Jan");
    kol.enqueue("Marek");
    kol.enqueue("Beata");
    kol.enqueue("Szymon");
    kol.enqueue("Anna");
   
    kol.display(std::cout);
    
    for(int i=0; i<3; i++)
        kol.dequeue();
    
    kol.display(std::cout);    
    
    kol.makeempty();

    kol.display(std::cout);
    
    return 0;
}
