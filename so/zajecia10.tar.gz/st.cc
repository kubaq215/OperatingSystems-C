template <typename T>
class Stack{
private:
    class Node{                 //węzeł stosu
    public:
        T item{};
        Node* next{};
        
        Node(const T& item_) : item{item_} {}
    };
    
    Node* head{};
    
    public:
        Stack() = default;      // konstruktor domyślny
        Stack(const Stack&);    // konstruktor kopiujący
        ~Stack();               // destruktor
        
        Stack& operator=(const Stack&); // operator podstawiania 
    
        void push(const T&);    // kładzie element na stosie
        T pop();                 // zdejmuje element ze stosu
        
        bool isEmpty() const;   // sprawdza, czy stos jest pusty
        void swap(Stack&);      // zamienia stos z innym stosem
    };
    
// kontruktor kopiujący

template <typename T>
Stack<T>::Stack(const Stack& stack)
{
    if(stack.head)
    {
        head = new Node{*stack.head};
        
        Node* oldNode{stack.head};
        Node* newNode{head};
        
        while(oldNode = oldNode->next)
        {
            newNode->next = new Node{*oldNode};
            newNode = newNode->next;
        }
        
    }
}
    
// destruktor

template <typename T>
Stack<T>::~Stack()
{
    while(head)
    {
        auto temp = head->next;
        delete head;
        head = temp;
    }
}

// operator podstawiania

template <typename T>
Stack<T>& Stack<T>::operator=(const Stack& rhs)
{
    auto copy{rhs};
    swap(copy);
    return *this;
}

// funkcja push kładzie element na stosie

template <typename T>
void Stack<T>::push(const T& item)
{
    Node* node{new Node{item}};
    node->next = head;
    head = node;
}

// funkcja pop zdejmuje element ze stosu

#include <iostream>
#include <cstdlib>

template <typename T>
T Stack<T>::pop()
{
    if(isEmpty())
    {
        std::cerr<<"Stos jest pusty !"<<std::endl;
        exit(1);
    }
    
    Node* temp{head};
    T item{head->item};
    head = head->next;
    delete temp;
    
    return item;    
}

template <typename T>
bool Stack<T>::isEmpty() const
{
    return head == nullptr;
}

template <typename T>
void Stack<T>::swap(Stack& other)
{
    std::swap(head, other.head);
}


#include <string>

int main()
{
    std::string imiona[] {"Jan", "Karol", "Beata", "Anna", "Zygmunt"};

    Stack<std::string> stosim{};
    
    for(int i{}; i<sizeof(imiona)/sizeof(std::string); i++)
        stosim.push(imiona[i]);
    
    Stack<std::string> stosimnew{stosim};   // kostruktor kopiujący
    
    while(not stosimnew.isEmpty())
        std::cout<<stosimnew.pop()<<std::endl;
    
    std::cout<<std::endl;
    
    while(not stosim.isEmpty())
        stosimnew.push(stosim.pop());
    
    while(not stosimnew.isEmpty())
        std::cout<<stosimnew.pop()<<std::endl;
    
    std::cout<<std::endl;
    
    return 0;
}
